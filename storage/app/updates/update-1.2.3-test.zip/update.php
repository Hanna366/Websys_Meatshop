<?php
function runUpdate($path, $fromVersion, $toVersion) {
    $out = "runUpdate executed: from={$fromVersion}, to={$toVersion}\n";
    file_put_contents($path . '/update-run.log', $out, FILE_APPEND);
    return ['success' => true, 'message' => 'simulated'];
}