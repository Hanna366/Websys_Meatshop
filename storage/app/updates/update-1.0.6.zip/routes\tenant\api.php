<?php

use App\Http\Controllers\ApiController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\InventoryController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ReportsController;
use App\Http\Controllers\SalesController;
use App\Http\Controllers\SubscriptionController;
use App\Http\Controllers\SupplierController;
use App\Models\User;
use App\Services\SubscriptionService;
use App\Services\EmailService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Tenant API Routes
|--------------------------------------------------------------------------
|
| Routes here are loaded only under tenancy middleware in the
| TenancyServiceProvider.
|
*/

Route::post('/auth/login', [AuthController::class, 'login']);

Route::middleware('auth:sanctum')->group(function () {
    Route::prefix('auth')->group(function () {
        Route::get('/profile', [AuthController::class, 'profile']);
        Route::put('/profile', [AuthController::class, 'updateProfile']);
        Route::post('/change-password', [AuthController::class, 'changePassword']);
        Route::post('/refresh', [AuthController::class, 'refresh']);
        Route::post('/logout', [AuthController::class, 'logout']);
    });

    Route::prefix('products')->group(function () {
        Route::get('/', [ProductController::class, 'index']);
        Route::get('/categories', [ProductController::class, 'categories']);
        Route::get('/search', [ProductController::class, 'search']);
        Route::get('/low-stock', [ProductController::class, 'lowStock']);
        Route::get('/{product}/current-price', [ProductController::class, 'currentPrice']);
        Route::post('/', [ProductController::class, 'store']);
        Route::get('/{product}', [ProductController::class, 'show']);
        Route::put('/{product}', [ProductController::class, 'update']);
        Route::delete('/{product}', [ProductController::class, 'destroy']);
    });

    Route::prefix('inventory')->group(function () {
        Route::get('/', [InventoryController::class, 'index']);
        Route::get('/stats', [InventoryController::class, 'stats']);
        Route::get('/alerts', [InventoryController::class, 'alerts']);
        Route::get('/product/{product}/batches', [InventoryController::class, 'productBatches']);
        Route::post('/batch', [InventoryController::class, 'addBatch'])->middleware('rbac.permission:can_manage_inventory');
        Route::put('/batch/{batch}', [InventoryController::class, 'updateBatch'])->middleware('rbac.permission:can_manage_inventory');
        Route::post('/batch/{batch}/waste', [InventoryController::class, 'recordWaste'])->middleware('rbac.permission:can_manage_inventory');
    });

    Route::prefix('sales')->group(function () {
        Route::get('/', [SalesController::class, 'index'])->middleware('rbac.permission:can_view_reports');
        Route::get('/summary', [SalesController::class, 'summary'])->middleware('rbac.permission:can_view_reports');
        Route::get('/daily-report', [SalesController::class, 'dailyReport'])->middleware('rbac.permission:can_view_reports');
        Route::post('/', [SalesController::class, 'process'])->middleware('rbac.permission:can_process_sales');
        Route::get('/{sale}', [SalesController::class, 'show'])->middleware('rbac.permission:can_view_reports');
        Route::post('/{sale}/void', [SalesController::class, 'void'])->middleware('rbac.permission:can_process_sales');
    });

    Route::prefix('customers')->group(function () {
        Route::get('/', [CustomerController::class, 'index']);
        Route::get('/{customer}', [CustomerController::class, 'show']);
        Route::post('/', [CustomerController::class, 'store']);
        Route::put('/{customer}', [CustomerController::class, 'update']);
        Route::delete('/{customer}', [CustomerController::class, 'destroy']);
        Route::get('/{customer}/purchase-history', [CustomerController::class, 'purchaseHistory']);
        Route::get('/{customer}/analytics', [CustomerController::class, 'analytics']);
        Route::post('/{customer}/loyalty/add', [CustomerController::class, 'addLoyaltyPoints']);
        Route::post('/{customer}/loyalty/redeem', [CustomerController::class, 'redeemLoyaltyPoints']);
    });

    Route::prefix('suppliers')->group(function () {
        Route::get('/', [SupplierController::class, 'index']);
        Route::get('/rankings', [SupplierController::class, 'rankings']);
        Route::post('/', [SupplierController::class, 'store']);
        Route::get('/{supplier}', [SupplierController::class, 'show']);
        Route::put('/{supplier}', [SupplierController::class, 'update']);
        Route::delete('/{supplier}', [SupplierController::class, 'destroy']);
        Route::put('/{supplier}/quality-score', [SupplierController::class, 'updateQualityScore']);
        Route::get('/{supplier}/performance', [SupplierController::class, 'performance']);
    });

    Route::prefix('reports')->group(function () {
        Route::get('/dashboard', [ReportsController::class, 'dashboard']);
        Route::get('/sales', [ReportsController::class, 'sales']);
        Route::get('/inventory', [ReportsController::class, 'inventory']);
        Route::get('/customers', [ReportsController::class, 'customers']);
        Route::get('/suppliers', [ReportsController::class, 'suppliers']);
        Route::get('/export', [ReportsController::class, 'export']);
    });

    Route::prefix('subscriptions')->group(function () {
        Route::get('/current', [SubscriptionController::class, 'current']);
        Route::get('/plans', [SubscriptionController::class, 'plans']);
        Route::get('/usage', [SubscriptionController::class, 'usage']);
        Route::get('/billing', [SubscriptionController::class, 'billing']);
        Route::post('/', [SubscriptionController::class, 'create']);
        Route::put('/plan', [SubscriptionController::class, 'update']);
        Route::put('/payment-method', [SubscriptionController::class, 'updatePaymentMethod']);
        Route::post('/cancel', [SubscriptionController::class, 'cancel']);
    });

    Route::prefix('notifications')->group(function () {
        Route::get('/', [NotificationController::class, 'index']);
        Route::get('/settings', [NotificationController::class, 'settings']);
        Route::put('/settings', [NotificationController::class, 'updateSettings']);
        Route::post('/low-stock', [NotificationController::class, 'sendLowStock']);
        Route::post('/expiry', [NotificationController::class, 'sendExpiry']);
        Route::post('/customer', [NotificationController::class, 'sendCustomer']);
    });

    Route::prefix('tenants')->group(function () {
        Route::get('/stats', function (Request $request) {
            $tenant = $request->user()->tenant;

            if (!$tenant) {
                return response()->json([
                    'success' => false,
                    'message' => 'Tenant context not found for authenticated user.',
                ], 404);
            }

            return response()->json([
                'success' => true,
                'data' => ['stats' => $tenant->getStats()],
            ]);
        });
    });

    Route::prefix('users')->group(function () {
        Route::get('/', function (Request $request) {
            $users = \App\Models\User::where('tenant_id', $request->user()->tenant_id)
                ->select('id', 'email', 'role', 'profile', 'status', 'created_at')
                ->orderBy('created_at', 'desc')
                ->paginate(50);

            return response()->json([
                'success' => true,
                'data' => ['users' => $users],
            ]);
        })->middleware('rbac.permission:can_manage_users');

        Route::post('/', function (Request $request) {
            $validated = $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|email|max:255',
                'password' => 'nullable|string|min:8', // Password optional for auto-generation
                'role' => 'required|in:owner,manager,cashier,inventory_staff',
                'profile' => 'nullable|array',
            ]);

            $tenantId = (string) $request->user()->tenant_id;
            $usersCount = User::where('tenant_id', $tenantId)->count();

            if (!SubscriptionService::isWithinLimit('max_users', $usersCount + 1)) {
                return response()->json([
                    'success' => false,
                    'message' => 'User limit reached for your current plan. Upgrade to add more users.',
                    'data' => [
                        'limit_key' => 'max_users',
                        'current_count' => $usersCount,
                        'plan' => SubscriptionService::resolveCurrentPlan(),
                    ],
                ], 403);
            }

            // Auto-generate password if not provided
            $password = $validated['password'] ?? EmailService::generateSecurePassword();

            $baseUsername = strtolower((string) preg_replace('/[^a-z0-9]+/i', '', (string) $validated['name']));
            if ($baseUsername === '') {
                $baseUsername = strtolower((string) strstr((string) $validated['email'], '@', true));
            }

            $baseUsername = $baseUsername ?: 'user';
            $username = $baseUsername;
            $counter = 1;
            while (User::where('tenant_id', $tenantId)->where('username', $username)->exists()) {
                $username = $baseUsername . $counter;
                $counter++;
            }

            $user = User::create([
                'tenant_id' => $tenantId,
                'username' => $username,
                'name' => $validated['name'],
                'email' => $validated['email'],
                'password' => Hash::make($password),
                'role' => $validated['role'],
                'profile' => $validated['profile'] ?? [],
                'status' => 'active',
            ]);

            // Send welcome email for all accounts (auto-generated password)
            $emailSent = false;
            if (!$validated['password']) {
                // Only send email if password was not provided (auto-generated)
                $tenant = \App\Models\Tenant::where('tenant_id', $tenantId)->first();
                $businessName = $tenant ? $tenant->business_name : 'Meat Shop POS';
                
                $emailResult = EmailService::sendWelcomeEmail(
                    $validated['email'],
                    $businessName,
                    $validated['role'],
                    $password
                );

                $emailSent = $emailResult['success'];
                
                // Log email result for debugging
                if (!$emailResult['success']) {
                    \Log::error("Failed to send welcome email to {$validated['email']} ({$validated['role']}): " . $emailResult['error']);
                }
            }

            $message = $emailSent 
                ? 'User created successfully! Welcome email sent with login credentials.'
                : 'User created successfully!' . (!$validated['password'] ? ' (Email notification failed - contact support)' : '');

            return response()->json([
                'success' => true,
                'message' => $message,
                'data' => [
                    'user' => $user->only(['id', 'name', 'email', 'role', 'status', 'created_at']),
                    'email_sent' => $emailSent,
                    'auto_generated_password' => !$validated['password'],
                ],
            ], 201);
        })->middleware('rbac.permission:can_manage_users');

        Route::get('/{user}', function (Request $request, $user) {
            $userData = \App\Models\User::where('tenant_id', $request->user()->tenant_id)
                ->whereKey($user)
                ->select('id', 'email', 'role', 'profile', 'status', 'created_at')
                ->first();

            if (!$userData) {
                return response()->json([
                    'success' => false,
                    'message' => 'User not found in tenant scope.',
                ], 404);
            }

            return response()->json([
                'success' => true,
                'data' => ['user' => $userData],
            ]);
        })->middleware('rbac.permission:can_manage_users');

        Route::get('/roles', function (Request $request) {
            $user = $request->user();
            $availableRoles = [];
            
            foreach (\App\Services\RbacService::getAvailableRoles() as $role) {
                if (\App\Services\RbacService::canAssignRole($user, $role)) {
                    $availableRoles[] = [
                        'value' => $role,
                        'label' => \App\Services\RbacService::getRoleDisplayName($role),
                        'description' => \App\Services\RbacService::getRoleDescription($role),
                    ];
                }
            }

            return response()->json([
                'success' => true,
                'data' => [
                    'available_roles' => $availableRoles,
                    'current_user_role' => $user->role,
                    'current_user_permissions' => \App\Services\RbacService::getRolePermissions($user->role),
                ],
            ]);
        });

        Route::get('/stats', function (Request $request) {
            $tenantId = $request->user()->tenant_id;
            $stats = \App\Services\RbacService::getRoleStats($tenantId);

            return response()->json([
                'success' => true,
                'data' => ['role_stats' => $stats],
            ]);
        })->middleware('rbac.permission:can_view_reports');
    });

    Route::prefix('v1')->middleware(['throttle:60,1'])->group(function () {
        Route::get('/docs', [ApiController::class, 'docs']);
        Route::get('/usage', [ApiController::class, 'usage']);
        Route::get('/products', [ApiController::class, 'products']);
        Route::post('/products', [ApiController::class, 'createProduct']);
        Route::get('/inventory/batches', [ApiController::class, 'inventoryBatches']);
        Route::post('/sales', [ApiController::class, 'createSale']);
        Route::get('/customers', [ApiController::class, 'customers']);
        Route::post('/customers', [ApiController::class, 'createCustomer']);
    });
});
