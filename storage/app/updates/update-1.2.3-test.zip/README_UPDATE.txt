This is a simulated update for version 1.2.3-test
