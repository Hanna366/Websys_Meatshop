<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        // $this->registerPolicies();

        // Implicitly share "auth" with all of its sub-routes
        // Gate::define('viewPulse', function ($user) {
        //     return in_array($user->email, [
        //         //
        //     ]);
        // });
    }
}
